package examen;

public interface IAterrizaje {
	
	public double calcularPrecioAterrizaje(double cantPorMetro, double cantExtra, double limiteCombustible,
			double cantPorPasajero, double extraPeligrosas);

}
